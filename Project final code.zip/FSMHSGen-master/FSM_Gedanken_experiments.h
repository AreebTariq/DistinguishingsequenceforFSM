
/*
 *
 * FSM_Gedanken_experiments.h: header file of implemented gedanken experiments over an FSM data structure
 *
*/

#include "FSM.h"
#include "integer_set.h"
#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

//extern variables to control the truncating rule of the tree generation 
extern size_t max_time;
extern size_t max_mem;
extern size_t max_length;

extern size_t max_time_for_ds;					/*Maximum time for the processing of distinguishing sequences*/
extern size_t max_mem_for_ds;					/*Maximum memory for the processing of distinguishing sequences*/
extern size_t max_length_for_ds;				/*Maximum depth of truncated tree for the distinguishing sequences*/
extern size_t initial_state_percentage_for_ds;  /*Percentage of initial states to start processing for the distinguishing sequence*/

//variables for reporting the average lenght of HS
size_t minlength_of_HSs;

size_t minlength_of_DSs;						/*Indicates the minimum length of distinguisging sequence*/

/*
 * displays to fd the homing sequences to the file descriptor, takes the max parameters as external arguments, the initial set should be an integer set with the initial states of the FSM (potentially all states) 
 * */
void display_hs (fsm_arr *fsm, integer_set *init_states, FILE *fd);

/*
* This is the main function to find the distinguishing sequence
* */
void display_ds (fsm_arr *fsm);

/*
* This is a main processing function to find the distinguishing sequences for a given FSM. 
* It takes FSM, initial level (root TST node), and output file. 
* */
void display_ds_preset_derivation(fsm_arr *fsm, linked_list *initial_level, FILE *fd);

/*
* This function deletes the truncated tree, which includes all levels, all nodes in all levels, 
* and all integer sets at each node.
* */
void delete_the_truncated_tree(linked_list *level_tree);

/*
* This function converts the fsm into all possible state pair (state subsets) for the root node.
* */
linked_list *convert_fsm_to_set_pairs(fsm_arr *fsm);

/*
* This function removes the redundant subsets present at given node.
* For example, the node containing {1,2} and {1,2} will have only just one {1,2} after this function.
* */
void remove_redundant_subsets(linked_list *node_subsets);

/*
* This function checks the presence of merging (any state pair have same states)at given node.
* For example, the node containing subset {1,1} will be called for merging after this function.
* */
int check_for_merging(linked_list *node_subsets);

/*
*  This function assists in finding and adding the next state pairs to next node. It takes a 
*  an intermediate list of transitions (next state and output). After processing, the function
*  makes pair of states with common output.
*/
void find_next_state_pairs(linked_list *intermediate_list, linked_list *next_node_list);

/*
* This function for a given FSM, finds the next possible state pair for a particular 'input' at 
* current node. This returns output state pairs from current state pairs with given input.
* */
linked_list *find_next_node(fsm_arr *fsm, linked_list *state_subsets, size_t input);

#ifdef __cplusplus
}
#endif
