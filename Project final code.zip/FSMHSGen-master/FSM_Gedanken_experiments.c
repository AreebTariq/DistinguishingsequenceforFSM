/*
 *
 * FSM_Gedanken_experiments.c: implemented gedanken experiments over an FSM data structure
 *
*/

#include "FSM_Gedanken_experiments.h"
#include "helpers.h"

#include <time.h>
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

//extern variables to control the truncating rule of the tree generation 
//extern size_t max_time;
//extern size_t max_mem;
//extern size_t max_length;

unsigned char state_subsets_are_singletons(linked_list *state_subsets)
{
	void *result = NULL;
	integer_set *state_subset = NULL;

	if(linked_list_transverse(state_subsets, &result))
	{
		state_subset = (integer_set*)result;
		if(integer_set_length(state_subset) != 1)//sin-gle-ton
			return 0;
	}
	while(linked_list_transverse(NULL, &result))
	{
		state_subset = (integer_set*)result;
		if(integer_set_length(state_subset) != 1)//sin-gle-ton
			return 0;
	}

	return 1;
}

//define how to separe a sequence, by dot or by space or by what?
char separator;

//variables for reporting the average lenght of HS
//size_t length_of_HSs;
//size_t number_of_HSs;

/*

size_t sequence_length (char *sequence)
{
	size_t length = 0;
	char *ptr = sequence;

	if(!sequence) //empty string
		return 0;
	
	while (ptr)
		if (*(ptr++) == separator)
			length++;

	//separator divides sequence in two sub sequences
	return length + 1;
} 
*/

/*
 * print_node: useful function to print a successor tree node, i.e., a list of subsets of states
 * */
void print_node(linked_list *ll)
{
	linked_list_node *aux = NULL;
	printf("{\n");
	aux = ll->head;
	while(aux)	
	{
		print_integer_set((integer_set*)aux->element);
		aux  = aux->next;
	}
	printf("}\n");
}

//useful to use the grouped outputs
#ifndef integer_set_output
typedef struct integer_set_output_tag
{
	size_t output;	
	integer_set *set;
}integer_set_output;
#endif
/*
 * i-successor: given a list of subsets of states of a given FSM, and an input i, returns a list (set) of subsets of successor states grouped by output
 * */

linked_list *i_successor(fsm_arr *fsm, linked_list *state_subsets, size_t input)
{
	linked_list *set_output_list = NULL, *node = NULL; 
	linked_list_node *subsets_ptr = NULL, *set_output_node = NULL;
	integer_set *subset = NULL;
	integer_set_node *state_ptr = NULL;
	integer_set_output *set_output = NULL;
	size_t s, index, start, end, j, o, n, transition, sizeofOComp;
	unsigned char found;

	if(!fsm || !state_subsets || input >= fsm->maxI)
		return NULL;

	sizeofOComp = ((size_t)(sizeof(size_t) * 8)) - fsm->sizeofO;
	subsets_ptr = state_subsets->head;

	node = create_linked_list();
	if(!node)
	{
		char *msg = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "Error! Could not allocate memory for i-succ list\n")));
		sprintf(msg, "Error! Could not allocate memory for i-succ list\n");
		fsm_log(error, msg);               
		free(msg);
		exit(1);
	}
	
	while(subsets_ptr)
	{
		set_output_list = create_linked_list();
		if(!set_output_list)
		{
			char *msg = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "Error! Could not allocate memory for i-succ list\n")));
			sprintf(msg, "Error! Could not allocate memory for i-succ list\n");
			fsm_log(error, msg);               
			free(msg);
			exit(1);
		}

		subset = (integer_set*)subsets_ptr->element;	
		
		state_ptr = (subset)?subset->head:NULL;
		
		while(state_ptr)
		{
			s = state_ptr->number;	
			index = s << fsm->sizeofI | input;
			start = fsm->indices[index];
			end = (s == (fsm->maxS - 1) && input == (fsm->maxI - 1))?fsm->trans:fsm->indices[index + 1];
			
			for (j = start; j < end; j++)//get all transitions classified by output
			{
				transition = fsm->transitions[j];
				n = transition >> fsm->sizeofO;
				o = (transition << sizeofOComp) >> sizeofOComp;
				set_output_node = set_output_list->head;
				found = 0;
				while(!found && set_output_node)
				{	
					//find output, add to corresponding set
					set_output = (integer_set_output*)set_output_node->element;
					if(set_output->output == o)
					{
						integer_set_add(set_output->set, n);
						found = 1;
						break;
					}
					set_output_node = set_output_node->next;
				}

				if(!found)//need to add to the working list
				{
					integer_set *new_subset = create_integer_set(); 
					integer_set_output *new_set_output = malloc(sizeof(integer_set_output));
							
					if(!new_subset || !new_set_output)
					{
						char *msg = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "Error! Could not allocate memory for i-succ list\n")));
						sprintf(msg, "Error! Could not allocate memory for i-succ list\n");
						fsm_log(error, msg);               
						free(msg);
						exit(1);
					}
					
					integer_set_add(new_subset, n);
					new_set_output->output = o;
					new_set_output->set = new_subset;
					
					linked_list_add(set_output_list, new_set_output);
				}
			}
		
			state_ptr = state_ptr->next;

		}

		//convert set output list to a simple list of subsets, i.e., from set_output_list -> node
		set_output_node = set_output_list->head;
		while(set_output_node)
		{
			set_output = (integer_set_output*)set_output_node->element;
			linked_list_add(node, set_output->set);
			set_output_node = set_output_node->next;
		}
		
		del_linked_list(set_output_list);
		subsets_ptr = subsets_ptr->next;
	}
	
	return node;
	
}

/*
 * defined_inputs: given a list of subsets of states of a given FSM, get a "list" of defined inputs for all states on the list of subsets. The list is given as an boolean array
 * */

unsigned char* defined_inputs(fsm_arr *fsm, linked_list *state_subsets)
{
	unsigned char *inputs  = NULL;
	integer_set *set = NULL;
	linked_list_node *set_ptr = NULL;
	integer_set_node *state_ptr = NULL;
	size_t s, i, index, start, end;
	
	
	if (!fsm || !state_subsets)
		return NULL;
	inputs = (unsigned char*)malloc(fsm->maxI * sizeof(unsigned char));
	if (!inputs)
	{
		char *msg = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "Error! Could not allocate memory for defined inputs\n")));
		sprintf(msg, "Error! Could not allocate memory for defined inputs\n");
		fsm_log(error, msg);               
		free(msg);
		exit(1);
	}
	memset(inputs, 1, fsm->maxI * sizeof(unsigned char));	
	
	set_ptr = state_subsets->head;
	
	while(set_ptr)	
	{
		set = (integer_set*)set_ptr->element;
		state_ptr = (set)?set->head:NULL;
		while(state_ptr)
		{
			s = state_ptr->number;
			for(i = 0; i < fsm->maxI; i++)
			{
				index = s << fsm->sizeofI | i;
				start = fsm->indices[index];
				end = (s == (fsm->maxS - 1) && i == (fsm->maxI - 1))?fsm->trans:fsm->indices[index + 1];
				if(start == end)
					inputs[i] = 0;
			}
			state_ptr = state_ptr->next;
		}
		set_ptr = set_ptr->next;
	}

	return inputs;
	
	
}

/*
 * del_subset_from_node: remove subsets in node, auxiliary function applied after i-successor to remove proper subsets of it
 * */
void del_subsets_from_node(linked_list **node)
{
	linked_list *ll = NULL;
	linked_list_node *subset_node = NULL, *subset_nodeaux = NULL, *subset_prev = NULL, *subset_prevaux;
	
	if(!node)
		return;

	ll = *node;


	if(!ll)
		return;
	subset_node = ll->head;
	subset_prev = ll->head;
	
	while(subset_node)
	{
		unsigned char head_deleted = 0;
		integer_set *A = (integer_set*)subset_node->element;
		subset_prevaux = subset_node;
		subset_nodeaux = subset_node->next;
		while(subset_nodeaux)
		{
			unsigned char compare;
			integer_set *B = (integer_set*)subset_nodeaux->element;
			compare = integer_set_compare(A, B);
			if(compare == AEQUALSB || compare == ACONTAINSB)//delete b, simple
			{
				subset_prevaux->next = subset_nodeaux->next; //
				subset_nodeaux->next = NULL;
				subset_nodeaux->element = NULL;
				delete_integer_set(B);
				free(subset_nodeaux);
				subset_nodeaux = subset_prevaux->next;
			}
			else if(compare == BCONTAINSA)//delete a
			{
				if(subset_node == ll->head) //take head into consideration and move head
				{	
					ll->head = ll->head->next;
					subset_prev = ll->head;					
					head_deleted = 1;
				}
				else
					subset_prev->next = subset_node->next;
				subset_node->next = NULL;
				subset_node->element = NULL;
				delete_integer_set(A);
				free(subset_node);
				subset_node = subset_prev;
				break;
			}
			else //delete nothing
			{
				subset_prevaux = subset_prevaux->next;
				subset_nodeaux = subset_nodeaux->next;
			}
		}
		if(!head_deleted)
		{
			subset_prev = subset_node;
			subset_node = subset_node->next;
		}
	}
	
}

//current usage variables
clock_t initial_time;
size_t used_mem = 0;
size_t HS_counter = 0;

#ifndef TST_node
typedef struct TST_node_tag
{
	char *sequence;
	linked_list *sss; //state subset set
}TST_node;
#endif


///state_subsets is a ll which contains integer sets represetning the subsets of states
void display_hs_preset_derivation(fsm_arr *fsm, linked_list *initial_level, FILE *fd)
{
	size_t level = 0, i;
	linked_list *current_level = NULL, *next_level = NULL, *sss = NULL, *isucc = NULL;
	linked_list_node *level_node = NULL, *ss_node = NULL, *ss_nodeaux = NULL;
	TST_node *node = NULL, *isucc_node = NULL;
	char *sequence = NULL, *inputs;
	
	if(!fsm || !initial_level)
		return;
	
	current_level = initial_level;
	
	while(linked_list_size(current_level))
	{
		level_node = current_level->head;
		next_level = create_linked_list();
		while(level_node)
		{
			node = (TST_node*)level_node->element;
			
			if(!node)
			{
				
				fsm_log(warning, "Warning! node is not a TST node\n");
				level_node = level_node->next;
				continue;
			}

			sss = node->sss;
			sequence = node->sequence;
	
			//check for HS rules
			size_t spent_time = (clock() - initial_time) / CLOCKS_PER_SEC;
			

			if(max_length && level > max_length) //default truncating rule for the tree, in exception of max_level being 0
			{
				char *msg = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "Reached Max depth = %llu with sequence %s\n", level, sequence) + 1));
				sprintf(msg, "Reached Max depth = %llu with sequence %s\n", level,  sequence);
				fsm_log(info, msg);
				free(msg);
				return;	
			}
	
			if(max_time && spent_time > max_time) //we finish inmediatelly, sorry :) 
			{
				char *msg = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "Homing sequence time expired: current time= %llu, max time = %llu\n", spent_time, max_time) + 1));
				sprintf(msg, "Homing sequence time expired: current time= %llu, max time = %llu\n", spent_time, max_time);
				fsm_log(info, msg);
				free(msg);
				return;	
			}

			if(max_mem && used_mem > max_mem) //we finish inmediatelly, sorry :) 
			/*2do: implement mem counter... aux functions that calculates frees and mallocs instead of directly calling them*/
			{
				char *msg = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "Homing sequence memory limit reached: current usage= %llu, max mem = %llu\n", used_mem, max_mem) + 1));
				sprintf(msg, "Homing sequence memory limit reached: current usage= %llu, max mem = %llu\n", used_mem, max_mem);
				fsm_log(info, msg);
				free(msg);
				return;	
			}
			//in here, we continue, i.e., we derive the next level based on the i-succ of nodes
			if(state_subsets_are_singletons(sss)) //Found a HS
			{	
				char *msg = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "Homing Sequence Found: %s\n", sequence) + 1));
				sprintf(msg, "Homing Sequence Found: %s\n", sequence);
				fsm_log(info, msg);
				free(msg);
				fprintf(fd, "HS: %s\n", sequence);
				minlength_of_HSs = (minlength_of_HSs > level || !minlength_of_HSs)?level:minlength_of_HSs; 
				HS_counter++;
			}

			inputs = defined_inputs(fsm, sss); 
			for(i = 0; i < fsm->maxI; i++)
			{	
				if(!inputs[i])//not defined input for the node 
					continue;
				isucc = i_successor(fsm, sss, i);
				if(isucc)
				{
					char *seq = NULL;
					del_subsets_from_node(&isucc);
					if(*sequence)//sequence is not empty
					{
						seq = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "%s%c%llu", sequence, separator,  i) + 1)); 
						sprintf(seq, "%s%c%llu", sequence, separator,  i);
					}
					else
					{
						seq = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "%llu", i) + 1)); 
						sprintf(seq, "%llu", i);
					}
		
					isucc_node = (TST_node*)malloc(sizeof(TST_node));
					isucc_node->sequence = seq;
					isucc_node->sss = isucc;
					linked_list_add(next_level, isucc_node);
				}
			}	

			free(inputs);

			//delete current node (already analyzed and we are not checking shortest squences)
			//delete sequence, easy :)
			free(node->sequence);
			//delete sss... a bit more complex	
			ss_node = node->sss->head;
			while(ss_node)
			{
				delete_integer_set((integer_set*)ss_node->element);
				ss_node = ss_node->next;
			}
			//finally, delete the node itself
			del_linked_list(node->sss);
			
			level_node = level_node->next;
		}
		level++;
		del_linked_list(current_level);
		current_level = next_level;
	}
}

/*
 * displays to fd the homing sequences to the file descriptor, takes the max parameters as external arguments, the initial set should be an integer set with the initial states of the FSM (potentially all states) 
 * */
void display_hs (fsm_arr *fsm, integer_set *init_states, FILE *fd)
{
	integer_set_node *aux = NULL;
	linked_list *init_node = NULL, *init_level= NULL; 
	integer_set *test_set = NULL;
	TST_node *initial_node = NULL;
	char *prefix = NULL;
	integer_set *initial_states = NULL;

	unsigned char *defined_i = NULL;
	size_t i;

	if(!fsm || !init_states || !fd)
		return;

	//check states are all valid for the fsm
	aux = init_states->head;
	while(aux)
	{
		if(aux->number >= fsm->maxS)
		{
			char *msg = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "Error! initial state %llu is greater or equal than FSM max state = %llu\n", aux->number, fsm->maxS ) + 1));
			sprintf(msg, "Error! initial state %llu is greater or equal than FSM max state = %llu\n", aux->number, fsm->maxS);
			fsm_log(error, msg);
			free(msg);
			return;
		}
		aux = aux->next;
	}
	
	initial_states = integer_set_clone(init_states);
		
	init_node = create_linked_list();
	linked_list_add(init_node, initial_states);
	prefix = (char*)malloc(1);
	*prefix = 0; //empty string
	initial_node = (TST_node*)malloc(sizeof(TST_node));
	initial_node->sequence = prefix;
	initial_node->sss = init_node;
	
	init_level = create_linked_list();
	linked_list_add(init_level, initial_node);

	separator = '.'; //very ascii, very common separator
	initial_time = clock();
	minlength_of_HSs = 0; 
	HS_counter = 0;

	//calculate the size of the fsm
	used_mem = (fsm->size + fsm->trans) * sizeof(size_t);
	//call the hs process
	display_hs_preset_derivation(fsm, init_level, fd);
	
	if (!HS_counter)
	{
		char *str_is = integer_set_to_string(init_states);
		char *msg = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "There is no homing sequence (using the current parameters parameters) for the initial state subset %s\n", str_is ) + 1));
		sprintf(msg, "There is no homing sequence (using the current parameters parameters) for the initial state subset %s\n", str_is);
		printf("%s", msg);
		fsm_log(info, msg);
		free(str_is);	
		free(msg);
	}
}

/*********************************************************************************************************************
				HERE IS THE CODE FOR FINDING THE DISTINGUISHING SEQUENCE FOR THE GIVEN FSM
**********************************************************************************************************************/
#define NO_MERGING (0)						/*Macro for default value of merging*/
#define MERGING_DETECTED (1)				/*Macro for presence of merging*/
#define NO_PRIOR_EXISTENCE_OF_NODE (0)		/*Macro for default value prior existence of current node in the path*/
#define PRIOR_EXISTENCE_OF_NODE (1)			/*Macro for prior existence of current node in the path*/
#define INVALID_VALUE (0xFF)				/*Macro for identification of invalid value*/


clock_t initial_time_for_ds; 				/*Variable to store the time at the start of distinguishing sequence processing*/
size_t DS_counter = 0;						/*Variable to indicate the total number of distinguishing sequence for the FSM*/
size_t used_mem_for_ds = 0;					/*Variable to indicate the used memory for the process of distinguishing sequence*/

/*********************************************************************************************************************
					Structure for the node in truncated tree for distinguishing sequence*/
#ifndef TST_node_ds
typedef struct TST_node_ds_tag
{
	char *sequence; 						/*Sequence of input to the current path of given node*/
	linked_list *sss; 						/*List of state subsets at given node*/
	struct TST_node_ds_tag *parent;			/*Pointer to the parent of given node in a truncated tree*/
}TST_node_ds;
#endif

/*********************************************************************************************************************
					Structure for the transistion of state machine for given state and input*/
#ifndef Transition_struct_ds
typedef struct Transition_struct_ds_tag
{
	size_t next_state;						/*Stores the next state value*/				
	size_t output;							/*Stores the output value*/
}Transition_struct_ds;
#endif

/*******************************************************************************************************************
* FUNCTION NAME: create_TST_node_ds()
* DESCRIPTION:  This function creates, initializes, and returns the TST node.
*******************************************************************************************************************/
TST_node_ds *create_TST_node_ds()
{
	TST_node_ds *node = (TST_node_ds*)malloc(sizeof(TST_node_ds));

	/*Checking the validity of 'TST node for ds' created*/
	if(!node)
	{
		return NULL;
	}
	
	node->sequence = 0;
	node->sss = NULL;
	node->parent = NULL;
	return node;
}

/*******************************************************************************************************************
* FUNCTION NAME: create_Transition_struct()
* DESCRIPTION:  This function creates, initializes and returns the Transition structure.
*******************************************************************************************************************/
TST_node_ds *create_Transition_struct()
{
	Transition_struct_ds *node = (Transition_struct_ds*)malloc(sizeof(Transition_struct_ds));

	/*Checking the validity of 'Transition structure' created*/
	if(!node)
	{
		return NULL;
	}

	node->next_state = INVALID_VALUE;
	node->output = INVALID_VALUE;

	return node;
}


/*******************************************************************************************************************
* FUNCTION NAME: convert_fsm_to_set_pairs(fsm_arr *fsm)
* DESCRIPTION:  This function converts the fsm into all possible state pair (state subsets) for the root node.
*******************************************************************************************************************/
linked_list  *convert_fsm_to_set_pairs(fsm_arr *fsm)
{
	linked_list *root_list = NULL;							/*List of all subsets (state pairs) at root*/
	size_t a,b;												/*Local variables to traverse the fsm to make pairs*/
	size_t initial_state_size;								/*Variable to control the initial states for processing for distinguishing sequences*/

	/*Check the validity of fsm*/
	if(!fsm)
	{
		return NULL;
	}

	/*Check the validity of initial state percentage*/
	if (initial_state_percentage_for_ds < 0 || initial_state_percentage_for_ds > 100)
	{
		return NULL;
	}

	/*Take the percent of initial states as requested by the user. Default = 100% (all states)*/
	initial_state_size = (initial_state_percentage_for_ds * (fsm->maxS))/100;

	root_list = create_linked_list();

	/*Create state pairs (subsets)*/
	for (a = 0; a < (initial_state_size)-1; a++)
	{
		for (b=a+1; b<(initial_state_size); b++)
		{
			integer_set *root_states = create_integer_set();
			integer_set_add(root_states, a);
			integer_set_add(root_states, b);

			linked_list_add_end(root_list, root_states);
		}
	}

	return root_list;
}

/*******************************************************************************************************************
* FUNCTION NAME: remove_redundant_subsets(linked_list *node_subsets)
* DESCRIPTION:  This function removes the redundant subsets present at given node.
				For example, the node containing {1,2} and {1,2} will have only just one {1,2} after this function.
*******************************************************************************************************************/
void remove_redundant_subsets(linked_list *node_subsets)
{
	/*Linked list node pointers for navigating and removal of redundant subsets at given TST node*/
	linked_list_node *subset_node = NULL, *subset_nodeaux = NULL, *subset_prev = NULL, *subset_prevaux;

	/*Check the validty of integer subsets list*/
	if(!node_subsets)
	{
		return;
	}

	subset_node = node_subsets->head;
	subset_prev = node_subsets->head;


	while(subset_node)
	{
		integer_set *A = (integer_set*)subset_node->element;
		subset_prevaux = subset_node;
		subset_nodeaux = subset_node->next;
		while(subset_nodeaux)
		{
			unsigned char compare;
			integer_set *B = (integer_set*)subset_nodeaux->element;

			compare = integer_set_compare(A, B);

			/*If two sets are equal, delete one set*/
			if(compare == AEQUALSB )
			{
				subset_prevaux->next = subset_nodeaux->next; 
				subset_nodeaux->next = NULL;
				subset_nodeaux->element = NULL;
				delete_integer_set(B);
				free(subset_nodeaux);
				subset_nodeaux = subset_prevaux->next;
			}
			else 
			{
				subset_prevaux = subset_prevaux->next;
				subset_nodeaux = subset_nodeaux->next;
			}
		}

		subset_prev = subset_node;
		subset_node = subset_node->next;
	}

}

/*******************************************************************************************************************
* FUNCTION NAME: check_for_merging(linked_list *node_subsets)
* DESCRIPTION:  This function checks the presence of merging (any state pair have same states)at given node.
				For example, the node containing subset {1,1} will be called for merging after this function.
*******************************************************************************************************************/
int check_for_merging(linked_list *node_subsets)
{
	int merge = NO_MERGING;									/*Variable to return the status of merging*/
	int list_size;
	linked_list_node *list_node = NULL;						/*Pointer to the list containing all the integer subsets*/
	integer_set *set = NULL;								/*Pointer to integer subset*/
	integer_set_node *set_node = NULL;						/*Pointer to the element of integer subset*/

	/*Check validity of integer subsets list*/
	if(!node_subsets)
	{
		return merge;
	}

	list_size = linked_list_size(node_subsets);
	

	/*Process to check the merging in state subsets at given node*/
	list_node = node_subsets->head;
	while(list_node)
	{
		set = (integer_set*)(list_node->element);
		set_node = set->head;
		if(set_node && set_node->next)
		{
			if(set_node->number == set_node->next->number)
			{
				merge = MERGING_DETECTED;
				/*Delete the redundant element in a set which has merging*/
				integer_set_delete_for_ds(set,set_node->number);
			}
			
		}
		list_node = list_node->next;
	}

	return merge;
}

/*******************************************************************************************************************
* FUNCTION NAME: compare_tst_nodes(TST_node_ds *node1, TST_node_ds *node2)
* DESCRIPTION:  This function compares the subsets (state pairs) at two nodes (current node and the all the parents)	
*******************************************************************************************************************/
int compare_tst_node_subsets(linked_list *subsets_1, linked_list *subsets_2)
{
	linked_list_node *subset_1_node = NULL, *subset_2_node = NULL; 		/*Pointer to traverse the integer subset lists*/
	integer_set *set_1 = NULL, *set_2 = NULL;							/*Pointer to traverse the integer subsets*/
	int same_nodes = 0;													/*Variable to indicate the similarity of nodes*/
	int common_set_count = 0;											/*Local variable for count the common sets b/w nodes*/

	/*If the number of state pairs are different at two nodes, they are not same*/
	if((linked_list_size(subsets_1) != linked_list_size(subsets_2)))
	{
		return same_nodes;
	}
	/*In case the number of state pair are same at both nodes, proceed below*/
	else
	{
		subset_1_node = subsets_1->head;

		/*Loop for state pair of first node subset list*/
		while(subset_1_node)
		{
			set_1 = (integer_set*)subset_1_node->element;

			subset_2_node = subsets_2->head;
		
			/*Loop for state pair of second node subset list*/
			while(subset_2_node)
			{
				set_2 = (integer_set*)subset_2_node->element;

				/*Compare each set pair of first node subset list with each set pair of second node subset list*/
				if(integer_set_compare(set_1, set_2) == AEQUALSB)
				{
					common_set_count++;
				}

				subset_2_node = subset_2_node->next;
			}

			subset_1_node = subset_1_node->next;
		}

	}

	/*If the number of common state pairs between two nodes is equal to number of state pairs at any node, 
	  then two nodes are identical*/
	if (common_set_count == linked_list_size(subsets_1))
	{
		same_nodes = 1;
	}

	return same_nodes;
}

/*******************************************************************************************************************
* FUNCTION NAME: check_for_prior_occurence(TST_node_ds *tst_node_ds)
* DESCRIPTION:  This function checks if this current node exists before in the path to this node within truncated tree
*******************************************************************************************************************/
int check_for_prior_occurence(TST_node_ds *tst_node_ds)
{
	int prior_occurence = NO_PRIOR_EXISTENCE_OF_NODE;		/*Local variable to indicate the prior existence*/
	TST_node_ds *parent_tst_node;							/*Pointer to parent node of selected node*/

	/*Check validity of TST node*/
	if(!tst_node_ds)
	{
		return prior_occurence;
	}

	/*Process to find the prior existence of this node in the path within the truncated tree*/
	parent_tst_node = tst_node_ds->parent;
	
	/*Traverse upward in the path in truncated tree till root from the current node*/
	while(parent_tst_node)
	{
		/*Compare each node in path with the current node. If they are similar, stop the process*/
		if (compare_tst_node_subsets(tst_node_ds->sss, parent_tst_node->sss) == 1)
		{
			prior_occurence = PRIOR_EXISTENCE_OF_NODE;
			break;
		}
		else
		{
			parent_tst_node = parent_tst_node->parent;
		}
	}

	return prior_occurence;
}

/*******************************************************************************************************************
* FUNCTION NAME: find_next_state_pairs(integer_set *transitions_list, linked_list *next_node_list)
* DESCRIPTION:   This function assists in finding and adding the next state pairs for next node. It takes a 
*				 a list of transitions (next state and output). After processing, the function
*				 makes pair of next states with common output.
*******************************************************************************************************************/
void find_next_state_pairs(linked_list *transitions_list, linked_list *next_node_list)
{
	/*Pointers to access the linked list (list of transition sets) nodes*/
	linked_list_node *transition_list_node_1 = NULL, *transition_list_node_2 = NULL;
	/*Pointers to access the transitions (next state and output) nodes*/
	Transition_struct_ds *trans_1 = NULL, *trans_2 = NULL;

	/*Checking validity of transitions_list*/
	if(!transitions_list)
	{
		return;
	}

	/*Navigate through the list of transitions (next state and output) and convert into state pairs*/
	transition_list_node_1 = transitions_list->head;
	
	/*Outer loop for transitions list*/
	while(transition_list_node_1->next != NULL)
	{
		trans_1 = (Transition_struct_ds*)(transition_list_node_1->element);

		transition_list_node_2 = transition_list_node_1->next;
		
		/*Inner loop for transitions list*/
		while(transition_list_node_2 != NULL)
		{

			trans_2 = (Transition_struct_ds*)(transition_list_node_2->element);

			/*If the output of two transitions is same, make a pair from next states given in transitions*/
			if(trans_1->output == trans_2->output)
			{
				integer_set *set = create_integer_set();
				integer_set_add_for_ds(set,trans_1->next_state);
				integer_set_add_for_ds(set,trans_2->next_state);
				linked_list_add_end(next_node_list,set);
			}

			transition_list_node_2 = transition_list_node_2->next;
		}

		transition_list_node_1 = transition_list_node_1->next;
	}

	/*Before exiting delete the transition list, as it not needed anymore*/
	transition_list_node_1 = transitions_list->head;

	while(transition_list_node_1)
	{
		free((Transition_struct_ds*)transition_list_node_1->element);
		transition_list_node_1 = transition_list_node_1->next;
	}

	del_linked_list(transitions_list);
}

/*******************************************************************************************************************
* FUNCTION NAME: *find_next_node(fsm_arr *fsm, linked_list *state_subsets, size_t input)
* DESCRIPTION:  This function for a given FSM, finds the next possible state pair for a particular 'input' at 
*				current node. This returns output state pairs from current state pairs with given input.
*******************************************************************************************************************/
linked_list *find_next_node(fsm_arr *fsm, linked_list *state_subsets, size_t input)
{
	linked_list *node = NULL, *transitions_list = NULL;			    /*Pointers to process the linked lists of subsets*/
	linked_list_node *subsets_ptr = NULL;							/*Pointer to the linked list node*/
	integer_set *subset = NULL;										/*Pointer to the integer subset at a linked list node*/
	integer_set_node *state_ptr=NULL;								/*Pointer to the element of integer subset*/
	size_t s, index, start, end, j, o, n, transition, sizeofOComp;	/*Local variables to process the transition table*/

	/*Check the validity of fsm, current node subsets, and input value*/
	if(!fsm || !state_subsets || input >= fsm->maxI)
	{
		char *msg = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "Error! Invalid FSM or state_subsets or input value received")));
		sprintf(msg, "Error! Invalid FSM or state_subsets or input value received");
		fsm_log(error, msg);
		free(msg);
		return NULL;
	}

	/*Process the transitions from current state pair to next state pair for a given 'input'*/
	sizeofOComp = ((size_t)(sizeof(size_t) * 8)) - fsm->sizeofO;
	subsets_ptr = state_subsets->head;

	node = create_linked_list();
	if(!node)
	{
		char *msg = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "Error! Could not allocate memory for list of next subsets\n")));
		sprintf(msg, "Error! Could not allocate memory for list of next subsets\n");
		fsm_log(error, msg);               
		free(msg);
		exit(1);
	}
	
	/*Loop for state pair at current node*/
	while(subsets_ptr)
	{
		subset = (integer_set*)subsets_ptr->element;	
		state_ptr = (subset)?subset->head:NULL;

		transitions_list = create_linked_list();
		if(!transitions_list)
		{
			char *msg = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "Error! Could not allocate memory for list of transitions\n")));
			sprintf(msg, "Error! Could not allocate memory for list of transitions\n");
			fsm_log(error, msg);               
			free(msg);
			exit(1);
		}
		
		/*Loop for states in given state pair at current node*/
		while(state_ptr)
		{
			s = state_ptr->number;

			index = s << fsm->sizeofI | input;
			start = fsm->indices[index];
			end = (s == (fsm->maxS - 1) && input == (fsm->maxI - 1))?fsm->trans:fsm->indices[index + 1];
			
			/* Get all transitions for given state of given state pair against the input received in function*/
			for (j = start; j < end; j++)
			{
				transition = fsm->transitions[j];
				n = transition >> fsm->sizeofO;
				o = (transition << sizeofOComp) >> sizeofOComp;

				/*Create a transition structure and add next state and output*/
				Transition_struct_ds *transition_struct = NULL;
				transition_struct = create_Transition_struct();

				transition_struct->next_state = n;
				transition_struct->output = o;

				/*Add this transition to the list of transitions*/
				linked_list_add_end(transitions_list,transition_struct);
	
			}
			
			state_ptr = state_ptr->next;
		}

		/*For given state pair, after finding the transitions above, find the next state pairs based on
		  common output, for next level node*/
		find_next_state_pairs(transitions_list, node);
		
		subsets_ptr = subsets_ptr->next;
	}

	return node;	
}

/*******************************************************************************************************************
* FUNCTION NAME: delete_the_truncated_tree(linked_list *level_tree)
* DESCRIPTION:  This function deletes the truncated tree, which includes all levels, all nodes in all levels, 
				and all integer sets at each node.
*******************************************************************************************************************/
void delete_the_truncated_tree(linked_list *level_tree)
{
	/*Pointers to access the lists in a truncated tree*/
	linked_list_node *pointer_for_levels = NULL, *pointer_for_tst_nodes = NULL, *pointer_to_integer_set = NULL;
	/*Pointer to access the linked list*/
	linked_list *pointer_to_nodes_in_level = NULL;
	/*Pointer to access the TST_node_ds in a list within a truncated tree*/
	TST_node_ds *pointer_for_tst_node_ds = NULL;

	/*Check for the validity of truncated tree*/
	if(!level_tree)
	{
		char *msg = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "Error! Invalid Truncated tree received")));
		sprintf(msg, "Error! Truncated tree received");
		fsm_log(error, msg);
		free(msg);
		return;
	}

	/*Point towards head of list of levels*/
	pointer_for_levels = level_tree->head;

	while(pointer_for_levels)
	{
		pointer_to_nodes_in_level = (linked_list*)pointer_for_levels->element;

		/*Point towards head of list of nodes in a given level*/
		pointer_for_tst_nodes = pointer_to_nodes_in_level->head;
		
		/*Loop for the nodes at given level*/
		while(pointer_for_tst_nodes)
		{
			
			pointer_for_tst_node_ds = (TST_node_ds*)pointer_for_tst_nodes->element;

			/*Free memory for sequence of current node*/
			free(pointer_for_tst_node_ds->sequence);

			/*Point towards head of list of integer set pairs in a given node and given level*/
			pointer_to_integer_set = pointer_for_tst_node_ds->sss->head;

			/*Loop for the integer sets at given node and given level*/
			while(pointer_to_integer_set)
			{
				/*Delete the each integer set at given node and given level*/
				delete_integer_set((integer_set*)pointer_to_integer_set->element);
				pointer_to_integer_set = pointer_to_integer_set->next;
			}

			del_linked_list(pointer_for_tst_node_ds->sss);

			pointer_for_tst_nodes = pointer_for_tst_nodes->next;

		}

		del_linked_list(pointer_to_nodes_in_level);

		pointer_for_levels = pointer_for_levels->next;

	}

	del_linked_list(level_tree);
	
}

/*******************************************************************************************************************
* FUNCTION NAME: display_ds_preset_derivation(fsm_arr *fsm, linked_list *initial_level, FILE *fd)
* DESCRIPTION:  This is a main processing function to find the distinguishing sequences for a given FSM. 
				It takes FSM, initial level (root TST node), and output file. It executes the following algorithm:

				1.  It moves from root level to downward levels in a truncated tree.
				2.  It process all the TST nodes at each level
				3.  For each node say node_i, it removes the redundant state pairs ({1,2} and {1,2})
				4.  For node_i, it checks for merging for each state pair ({1,1} --> merging detected). 
				    If yes, truncate node. Else, continue processing.
				5.  For node_i, it checks for the existence of this node prior in the path from the root. 
				    If yes, truncate node. Else, continue processing.
				6.  For node_i, it checks for the presence of all singelton sets at a given node.
				    If yes, truncate node and the sequence of input from root to this point is distinguising sequence.
				    Else, continue processing.
				7.  For node_i, find the defined inputs for the state pairs.
				8.  For each input say input_i and node_i, find the next possible node containing possible state pairs.
				9.  Possibly, the next nodes from node_i will be equal to the number of defined inputs for node_i.
				10. Add all possible next nodes to the next level in the truncated tree.
				11. Repeat the same process from Step#2
*******************************************************************************************************************/
void display_ds_preset_derivation(fsm_arr *fsm, linked_list *initial_level, FILE *fd)
{
	size_t level = 0, i;
	/*Pointers for the linked lists used in this function*/
	linked_list *current_level = NULL, *next_level = NULL, *sss = NULL, *isucc = NULL, *level_list = NULL;
	/*Pointer to nodes of linked lists used in this function*/
	linked_list_node *level_node = NULL;
	/*Pointers to the TST nodes in a truncated tree for distinguishing sequence*/
	TST_node_ds *node = NULL, *isucc_node = NULL;
	/*Pointers for the input and input sequence*/
	char *sequence = NULL, *inputs;

	/*Check for the validity of FSM and the intial level (root)*/
	if(!fsm || !initial_level)
	{
		char *msg = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "Error! Invalid FSM received")));
		sprintf(msg, "Error! Invalid FSM received");
		fsm_log(error, msg);
		free(msg);
		return;
	}
	
	/*Set the initial level to the current level*/
	current_level = initial_level;

	/*Create a list for levels of truncated tree*/
	level_list = create_linked_list();

	if(!level_list)
	{
		char *msg = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "Error! Could not allocate memory for level_list linked list for distinguishing sequence\n")));
		sprintf(msg, "Error! Could not allocate memory for level_list linked list for distinguishing sequence\n");
		fsm_log(error, msg);               
		free(msg);
		exit(1);
	}

	/*Loop for the levels in a truncated tree*/
	while(linked_list_size(current_level))
	{
		/*Add current level to the list of levels of truncated tree*/
		linked_list_add_end(level_list, current_level);

		level_node = current_level->head;
		next_level = create_linked_list();

		while(level_node)
		{
			node = (TST_node_ds*)level_node->element;
			
			if(!node)
			{
				fsm_log(warning, "Warning! node is not a TST node for distinguishing sequence\n");
				level_node = level_node->next;
				continue;
			}

			sss = node->sss;
			sequence = node->sequence;

			
			/*Verify the rules for distinguishing sequence, given by configuration*/
			
			/*Rule-1: Spent time*/
			/*If spent time is more than the maximum allocated time, stop processing*/
			size_t spent_time_for_ds = (clock() - initial_time_for_ds) / CLOCKS_PER_SEC;

			if(max_time_for_ds && spent_time_for_ds > max_time_for_ds)  
			{
				char *msg = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "Distinguishing sequence time expired: current time= %llu, max time = %llu\n", spent_time_for_ds, max_time_for_ds) + 1));
				sprintf(msg, "Distinguishing sequence time expired: current time= %llu, max time = %llu\n", spent_time_for_ds, max_time_for_ds);
				fsm_log(info, msg);
				free(msg);
				return;	
			}
			
			/*Rule-2: Length of tree*/
			/*If current depth of truncated tree is more than the maximum allocated depth, stop processing*/
			if(max_length_for_ds && level > max_length_for_ds) 
			{
				char *msg = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "Reached Max depth = %llu with sequence %s\n", level, sequence) + 1));
				sprintf(msg, "Reached Max depth = %llu with sequence %s\n", level,  sequence);
				fsm_log(info, msg);
				free(msg);
				return;	
			}
	
			/*Rule-3: Memory for the process*/
			/*If current used memory for the process of distinguishing sequence is more than the maximum allocated memory, stop processing*/
			if(max_mem_for_ds && used_mem_for_ds > max_mem_for_ds) 
			{
				char *msg = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "Distinguishing sequence memory limit reached: current usage= %llu, max mem = %llu\n", used_mem_for_ds, max_mem_for_ds) + 1));
				sprintf(msg, "Homing sequence memory limit reached: current usage= %llu, max mem = %llu\n", used_mem, max_mem);
				fsm_log(info, msg);
				free(msg);
				return;	
			}

			/*Remove redundant subsets present in current node*/
			remove_redundant_subsets(node->sss);

			/*Check for merging in subsets present in current node*/
			if(check_for_merging(node->sss) == MERGING_DETECTED)
			{
				/*Truncate this node and move to next node (if present) in current level*/
				level_node = level_node->next;
				continue;
			}

			/*Check for the previous existence of this node in its path from the root*/
			if(check_for_prior_occurence(node)==PRIOR_EXISTENCE_OF_NODE)
			{
				/*Truncate this node and move to next node (if present) in current level*/
				level_node = level_node->next;
				continue;
			}

			/*Check for the presence of all singeltons present in current node*/
			if(state_subsets_are_singletons(node->sss)) //Found a DS
			{	
				char *msg = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "Distinguishing Sequence Found: %s\n", sequence) + 1));
				sprintf(msg, "Distinguishing Sequence Found: %s\n", sequence);
				fsm_log(info, msg);
				free(msg);
				fprintf(fd, "DS: %s\n", sequence);
				minlength_of_DSs = (minlength_of_DSs > level || !minlength_of_DSs)?level:minlength_of_DSs; 
				DS_counter++;


				/*FOUND A DISTINGUISHING SEQUENCE
				Truncate this node and move to next node (if present) in current level*/
				level_node = level_node->next;
				continue;
			}

			/*Find the possible defined inputs for the state pairs present in current node from transition table*/
			inputs = defined_inputs(fsm, node->sss);

			/*Loop for each input*/
			for(i = 0; i < fsm->maxI; i++)
			{	
				/*If input is not defined for this node, skip this input*/
				if(!inputs[i])
				{
					continue;
				}
				
				/*Find the successor node for selected input at current node*/
				isucc = find_next_node(fsm, node->sss, i);
				
				if(isucc)
				{
					char *seq = NULL;

					/*Add selected input to the sequence for the next node*/
					if(*sequence)
					{
						seq = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "%s%c%llu", sequence, separator,  i) + 1)); 
						sprintf(seq, "%s%c%llu", sequence, separator,  i);
					}
					else
					{
						seq = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "%llu", i) + 1)); 
						sprintf(seq, "%llu", i);
					}
		
					/*Create the next node in a truncated treefor distinguishing sequence */
					isucc_node = create_TST_node_ds();
					
					/*Add sequence*/
					isucc_node->sequence = seq;
					
					/*Add i-successor state pairs*/
					isucc_node->sss = isucc;

					/*Add current node as parent to the next node*/
					isucc_node->parent = node;

					/*Add this node to the next level*/
					linked_list_add_end(next_level, isucc_node);		
				}
			}

			free(inputs);

			/*Move to next node at current level*/
			level_node = level_node->next;
		}
		/*Counter for truncated tree depth*/
		level++;

		/*Move to the next level in a truncated tree*/
		current_level = next_level;
	}

	/*Delete the truncated tree at the end*/
	delete_the_truncated_tree(level_list);
}


/*******************************************************************************************************************
* FUNCTION NAME: ds()
* DESCRIPTION:  This is the main function to find the distinguishing sequence
*******************************************************************************************************************/
void ds(fsm_arr *fsm)
{
	linked_list *root_list = NULL;					/*List of subsets (state pairs) at root of truncated tree*/
	linked_list *current_level = NULL;				/*List of all nodes at given level of truncated treee*/
	TST_node_ds *tst_node_ds = NULL;				/*TST node containing all state pairs*/
	char *prefix = NULL;

	/*Convert FSM into all possible state pairs*/
	root_list = convert_fsm_to_set_pairs(fsm);

	if (root_list == NULL)
	{
		char *msg = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "Error! Failed to create the root of truncated tree for distinguishing sequence")));
		sprintf(msg, "Error! Failed to create the root of truncated tree for distinguishing sequence");
		fsm_log(error, msg);
		free(msg);
		return;
	}

	/*Initialize '0' for sequence at the beginning*/
	prefix = (char*)malloc(1);
	*prefix = 0; 

	/*Create TST node and assign the state pairs to it*/
	tst_node_ds= create_TST_node_ds();

	if(!tst_node_ds)
	{
		char *msg = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "Error! Could not allocate memory for TST_node for distinguishing sequence\n")));
		sprintf(msg, "Error! Could not allocate memory for TST_node for distinguishing sequence\n");
		fsm_log(error, msg);               
		free(msg);
		exit(1);
	}

	tst_node_ds->sequence = prefix;
	tst_node_ds->sss = root_list;
	tst_node_ds->parent = NULL;


	/*Add this node to the current level of truncated tree*/
	current_level = create_linked_list();

	if(!current_level)
	{
		char *msg = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "Error! Could not allocate memory for current_level linked list for distinguishing sequence\n")));
		sprintf(msg, "Error! Could not allocate memory for current_level linked list for distinguishing sequence\n");
		fsm_log(error, msg);               
		free(msg);
		exit(1);
	}

	linked_list_add(current_level,tst_node_ds);

	/*Separator between each element of distinguishing sequence*/
	separator = '.'; 

	/*Record initial time at the beginning of processing*/
	initial_time_for_ds = clock();

	/*Set the minimum length for distinguishing sequence equal to zero*/
	minlength_of_DSs = 0; 

	/*Initialze counter of distinguishing sequence to zero*/
	DS_counter = 0;

	/* Calculate the size of the fsm*/
	used_mem = (fsm->size + fsm->trans) * sizeof(size_t);

	/*Call the function to start processing for distinguishing sequence*/
	display_ds_preset_derivation(fsm,current_level,stdout);
	
	/*If there is no distinguishing sequence, indicate the user*/
	if (!DS_counter)
	{
		char *msg = (char*)malloc(sizeof(char)*(snprintf(NULL, 0, "There is no distinguishing sequence (using the current parameters parameters) for the initial state subset\n") + 1));
		sprintf(msg, "There is no distinguishing sequence (using the current parameters parameters) for the initial state subset \n");
		printf("%s", msg);
		fsm_log(info, msg);
		free(msg);
	}

	return;
}

/******************************************************************************************************************/


#ifdef __cplusplus
}
#endif
